// const hamburger = document.querySelector(".hamburger");
// const Navlinks = document.querySelector(".nav-links");
// const links = document.querySelector(".nav-links li");

// hamburger.addEventListener('click',  ()=>{
//     Navlinks.classList.toggle("open");
//     links.forEach(link => {
//         link.classList.toggle('fade');
//     });
// })