This is a commercial Mobiscroll package, licensed to Stanley Baker <sbaker@leapinglogic.com> with license key 907472f7-e79d-4820-9142-7210ca43affa. 

In case of perpetual licenses please refer to the EULA licensing terms (present in the license folder) or https://mobiscroll.com/EULA for more info.

In case of SaaS licenses please refer to the license agreement you agreed to. 