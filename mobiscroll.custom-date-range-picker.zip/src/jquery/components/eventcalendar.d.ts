import { Eventcalendar as EventcalendarComponent } from '../../core/components/eventcalendar/eventcalendar.common';
export { formatDate, getJson, MbscCalendarEvent, MbscCalendarEventData, MbscCellClickEvent, MbscCellHoverEvent, MbscEventcalendarOptions, MbscEventcalendarView, MbscEventClickEvent, MbscEventCreateEvent, MbscEventCreateFailedEvent, MbscEventCreatedEvent, MbscEventDeleteEvent, MbscEventDeletedEvent, MbscEventUpdateEvent, MbscEventUpdateFailedEvent, MbscEventUpdatedEvent, MbscLabelClickEvent, MbscPageChangeEvent, MbscPageLoadingEvent, MbscPageLoadedEvent, MbscResource, MbscSelectedDateChangeEvent, momentTimezone, luxonTimezone, parseDate, } from '../../core/components/eventcalendar/eventcalendar';
export * from '../shared/calendar-header';
export * from './draggable';
declare class Eventcalendar extends EventcalendarComponent {
    static _fname: string;
    static _renderOpt: import("../../preact/renderer").IRenderOptions;
}
export { Eventcalendar, };
