import { IRenderOptions } from '../renderer';
export declare const inputRenderOptions: IRenderOptions;
export declare const selectRenderOptions: IRenderOptions;
export declare const textareaRenderOptions: IRenderOptions;
