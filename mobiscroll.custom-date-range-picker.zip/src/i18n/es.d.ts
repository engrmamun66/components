import { MbscLocale } from './locale';
declare const es: MbscLocale;
export default es;
