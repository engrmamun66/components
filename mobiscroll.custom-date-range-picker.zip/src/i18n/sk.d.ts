import { MbscLocale } from './locale';
declare const sk: MbscLocale;
export default sk;
