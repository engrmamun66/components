import { MbscLocale } from './locale';
declare const hu: MbscLocale;
export default hu;
