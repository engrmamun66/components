import { MbscLocale } from './locale';
declare const pl: MbscLocale;
export default pl;
