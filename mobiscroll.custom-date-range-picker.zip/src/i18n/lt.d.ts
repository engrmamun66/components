import { MbscLocale } from './locale';
declare const lt: MbscLocale;
export default lt;
