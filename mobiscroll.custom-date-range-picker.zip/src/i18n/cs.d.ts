import { MbscLocale } from './locale';
declare const cs: MbscLocale;
export default cs;
