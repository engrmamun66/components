import { MbscLocale } from './locale';
declare const ja: MbscLocale;
export default ja;
