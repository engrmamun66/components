import { MbscCalendarSystem } from '../core/commons';
export declare const hijriCalendar: MbscCalendarSystem;
