import { MbscLocale } from './locale';
declare const fi: MbscLocale;
export default fi;
