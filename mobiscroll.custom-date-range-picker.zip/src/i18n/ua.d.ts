import { MbscLocale } from './locale';
declare const ua: MbscLocale;
export default ua;
