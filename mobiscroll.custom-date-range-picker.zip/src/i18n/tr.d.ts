import { MbscLocale } from './locale';
declare const tr: MbscLocale;
export default tr;
