import { MbscLocale } from './locale';
declare const no: MbscLocale;
export default no;
