import { MbscLocale } from './locale';
declare const enGB: MbscLocale;
export default enGB;
