import { MbscLocale } from './locale';
declare const nl: MbscLocale;
export default nl;
