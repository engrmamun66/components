import { MbscCalendarSystem } from '../core/commons';
export declare const jalaliCalendar: MbscCalendarSystem;
