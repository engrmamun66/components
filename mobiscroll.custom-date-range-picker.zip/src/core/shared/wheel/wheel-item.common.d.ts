import { IWheelItemProps, WheelItemBase } from './wheel-item';
/** @hidden */
export declare class WheelItem extends WheelItemBase {
    protected _template(s: IWheelItemProps): any;
}
