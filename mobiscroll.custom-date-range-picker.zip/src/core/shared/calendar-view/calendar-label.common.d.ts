import { CalendarLabelBase, ICalendarLabelProps } from './calendar-label';
/** @hidden */
export declare class CalendarLabel extends CalendarLabelBase {
    protected _template(s: ICalendarLabelProps): any;
}
