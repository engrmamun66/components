import { IMonthViewProps, MonthViewBase } from './month-view';
/** @hidden */
export declare class MonthView extends MonthViewBase {
    protected _template(s: IMonthViewProps): any;
}
