import { IPickerProps, IPickerState, PickerBase } from './picker';
export declare function template(inst: PickerBase<IPickerProps, IPickerState>, s: IPickerProps, content: any): any;
