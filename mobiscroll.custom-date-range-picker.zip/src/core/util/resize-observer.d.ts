export declare function resizeObserver(el: HTMLElement, callback: () => void, zone?: any): {
    detach(): void;
};
