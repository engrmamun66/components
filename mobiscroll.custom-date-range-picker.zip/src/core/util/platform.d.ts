declare let os: string;
declare let majorVersion: number;
declare let minorVersion: number;
declare let touchUi: boolean;
declare const isBrowser: boolean;
declare const isDarkQuery: MediaQueryList;
declare const userAgent: string;
declare const isSafari: boolean;
export { os, majorVersion, minorVersion, isBrowser, isDarkQuery, isSafari, touchUi, userAgent, };
