/** @hidden */
export declare function gestureListener(elm: HTMLElement, options: any): () => void;
