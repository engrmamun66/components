import { Date } from './date.common';
export declare class Datetime extends Date {
    protected _preset: string;
}
