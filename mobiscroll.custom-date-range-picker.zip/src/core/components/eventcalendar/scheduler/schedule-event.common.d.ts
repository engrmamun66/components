import { MbscScheduleEventOptions, ScheduleEventBase } from './schedule-event';
/** @hidden */
export declare class ScheduleEvent extends ScheduleEventBase {
    protected _template(s: MbscScheduleEventOptions): any;
}
