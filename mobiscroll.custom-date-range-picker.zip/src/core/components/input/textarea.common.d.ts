import { Input } from './input.common';
export declare class Textarea extends Input {
    protected static _name: string;
    protected _tag: string;
}
