/** @jsx createElement */
import { DraggableBase, MbscDraggableOptions } from './draggable';
export declare class Draggable extends DraggableBase {
    protected _template(s: MbscDraggableOptions): any;
}
