import { MbscPageOptions, PageBase } from './page';
import '../../base.scss';
import './page.scss';
export declare class Page extends PageBase {
    protected _template(s: MbscPageOptions): import("../../../preact/lib/src").VNode<any>;
}
