import { ListItemBase, MbscListItemOptions } from './list-item';
/**
 * The ListItem component
 */
export declare class ListItem extends ListItemBase {
    protected _template(s: MbscListItemOptions): any;
}
