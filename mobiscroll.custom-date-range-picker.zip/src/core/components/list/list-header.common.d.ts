import { ListHeaderBase, MbscListHeaderOptions } from './list-header';
/**
 * The ListItem component
 */
export declare class ListHeader extends ListHeaderBase {
    protected _template(s: MbscListHeaderOptions): any;
}
