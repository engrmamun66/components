import { IModule } from './base';
export interface MbscPrintConfig {
    baseUrl?: string;
}
export declare const print: IModule;
