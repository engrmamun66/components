declare const _default: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"36\" height=\"36\" viewBox=\"0 0 36 36\"><path d=\"M15 9l-2.12 2.12L19.76 18l-6.88 6.88L15 27l9-9z\"/></svg>";
export default _default;
